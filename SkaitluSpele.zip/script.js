
let numberToGuess = Math.floor(Math.random() * 100) + 1;
let attempts = 0;
let lastHint = "";
let repeatCount = 1;

function checkGuess() {
  const userGuess = parseInt(document.getElementById("guess").value);
  const message = document.getElementById("message");
  attempts++;

  if (isNaN(userGuess)) {
    message.textContent = "Ievadi derīgu skaitli!";
    return;
  }

  if (attempts >= 5) {
    numberToGuess = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    repeatCount = 1;
    lastHint = "";
    message.textContent = "Tu neuzminēji, es izdomāju jaunu skaitli – mēģini vēlreiz :)";
    return;
  }

  let currentHint = "";

  if (userGuess < numberToGuess) {
    currentHint = "Par mazu!";
  } else if (userGuess > numberToGuess) {
    currentHint = "Par lielu!";
  } else {
    message.textContent = `Pareizi! Tev vajadzēja ${attempts} mēģinājumus.`;
    numberToGuess = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    repeatCount = 1;
    lastHint = "";
    return;
  }

  if (currentHint === lastHint) {
    repeatCount++;
    message.textContent = `${currentHint} x${repeatCount}`;
  } else {
    repeatCount = 1;
    message.textContent = currentHint;
  }

  lastHint = currentHint;
}
